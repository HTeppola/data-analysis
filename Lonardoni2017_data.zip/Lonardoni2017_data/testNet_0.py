__author__ = 'dlonardoni'

import pylab as plt
import cellCultureNet as Net

plt.ion()
Net.StartSmallNetTest()
plt.show()