#! /bin/bash

nrnivmodl nrnMod/